require('dotenv').config();

module.exports = {
    telegram: {
        token: process.env.TELEGRAM_TOKEN || 'YOUR_TELEGRAM_BOT_TOKEN',
        adminId: process.env.ADMIN_ID || 'YOUR_TELEGRAM_ID'
    },
    whatsapp: {
        prefix: '.',
        ownerNumber: 'YOUR_PHONE_NUMBER', // e.g. 2348123456789
        botName: 'MultiBot',
        pairingCode: true // Use pairing code instead of QR
    },
    dbPath: './src/database/db.json',
    sessionPath: './sessions',
    port: process.env.PORT || 3000,
    logging: {
        level: 'info'
    }
};
