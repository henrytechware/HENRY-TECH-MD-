const logger = require('./lib/logger');
const db = require('./lib/database');
const telegramManager = require('./lib/telegram');
const whatsappManager = require('./lib/whatsapp');
const express = require('express');
const config = require('./config');

async function start() {
    logger.info('Starting Multi-Bot System...');

    // Initialize Database
    await db.init();

    // Initialize Telegram Bot
    const telegram = telegramManager;

    // Initialize Express Dashboard (Optional)
    const app = express();
    app.get('/', (req, res) => {
        res.send('Multi-Bot System is running! 🤖');
    });
    app.listen(config.port, () => {
        logger.info(`Dashboard running on port ${config.port}`);
    });

    // Handle Uncaught Errors
    process.on('uncaughtException', (err) => {
        logger.error('Uncaught Exception:', err);
    });
    process.on('unhandledRejection', (reason, promise) => {
        logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
    });

    logger.info('System is ready!');
}

start();
