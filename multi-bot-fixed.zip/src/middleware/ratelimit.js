const NodeCache = require('node-cache');
const rateLimitCache = new NodeCache({ stdTTL: 60 }); // 1 minute TTL

const rateLimit = (userId, limit = 10) => {
    const current = rateLimitCache.get(userId) || 0;
    if (current >= limit) {
        return true; // Rate limited
    }
    rateLimitCache.set(userId, current + 1);
    return false;
};

module.exports = { rateLimit };
