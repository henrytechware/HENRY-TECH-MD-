const logger = require('../lib/logger');
const db = require('../lib/database');

const spamCache = new Map(); // userId -> { count, lastTime }

const antibug = async (sock, msg, from, isGroup) => {
    try {
        const sender = msg.key.participant || msg.key.remoteJid;
        const body = msg.message.conversation || 
                     msg.message.extendedTextMessage?.text || '';

        // 1. Spam Protection
        const now = Date.now();
        const userSpam = spamCache.get(sender) || { count: 0, lastTime: now };
        
        if (now - userSpam.lastTime < 2000) { // 2 seconds window
            userSpam.count++;
        } else {
            userSpam.count = 1;
        }
        userSpam.lastTime = now;
        spamCache.set(sender, userSpam);

        if (userSpam.count > 5) { // More than 5 messages in 2 seconds
            logger.warn(`Spam detected from ${sender}`);
            if (isGroup) {
                await sock.sendMessage(from, { text: `🚫 @${sender.split('@')[0]} detected for spamming.`, mentions: [sender] });
                await sock.groupParticipantsUpdate(from, [sender], 'remove');
            } else {
                await sock.updateBlockStatus(sender, 'block');
            }
            return true; // Stop processing
        }

        // 2. Anti-Link System (if enabled in DB)
        const settings = db.getSettings();
        if (isGroup && settings.antilink && (body.includes('http://') || body.includes('https://'))) {
            const groupMetadata = await sock.groupMetadata(from);
            const admins = groupMetadata.participants.filter(v => v.admin !== null).map(v => v.id);
            if (!admins.includes(sender)) {
                await sock.sendMessage(from, { delete: msg.key });
                await sock.sendMessage(from, { text: `🚫 Links are not allowed in this group, @${sender.split('@')[0]}!`, mentions: [sender] });
                return true;
            }
        }

        // 3. Anti-Bad Words
        const badWords = ['spam', 'scam', 'fuck', 'bitch']; // Example list
        if (badWords.some(word => body.toLowerCase().includes(word))) {
            await sock.sendMessage(from, { delete: msg.key });
            return true;
        }

        return false; // Continue processing
    } catch (err) {
        logger.error('Antibug middleware error:', err);
        return false;
    }
};

module.exports = { antibug };
