module.exports = {
    kick: async (sock, msg, from, args, isGroup) => {
        if (!isGroup) return sock.sendMessage(from, { text: "This command only works in groups." }, { quoted: msg });
        const user = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : msg.message.extendedTextMessage?.contextInfo?.participant;
        if (!user) return sock.sendMessage(from, { text: "Please mention a user or provide a number." }, { quoted: msg });
        await sock.groupParticipantsUpdate(from, [user], 'remove');
        await sock.sendMessage(from, { text: `✅ User ${user} kicked.` }, { quoted: msg });
    },
    promote: async (sock, msg, from, args, isGroup) => {
        if (!isGroup) return sock.sendMessage(from, { text: "This command only works in groups." }, { quoted: msg });
        const user = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : msg.message.extendedTextMessage?.contextInfo?.participant;
        if (!user) return sock.sendMessage(from, { text: "Please mention a user or provide a number." }, { quoted: msg });
        await sock.groupParticipantsUpdate(from, [user], 'promote');
        await sock.sendMessage(from, { text: `✅ User ${user} promoted to admin.` }, { quoted: msg });
    },
    demote: async (sock, msg, from, args, isGroup) => {
        if (!isGroup) return sock.sendMessage(from, { text: "This command only works in groups." }, { quoted: msg });
        const user = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : msg.message.extendedTextMessage?.contextInfo?.participant;
        if (!user) return sock.sendMessage(from, { text: "Please mention a user or provide a number." }, { quoted: msg });
        await sock.groupParticipantsUpdate(from, [user], 'demote');
        await sock.sendMessage(from, { text: `✅ User ${user} demoted.` }, { quoted: msg });
    },
    tagall: async (sock, msg, from, args, isGroup) => {
        if (!isGroup) return sock.sendMessage(from, { text: "This command only works in groups." }, { quoted: msg });
        const groupMetadata = await sock.groupMetadata(from);
        const participants = groupMetadata.participants;
        let text = `📢 *Tag All*\n\n${args.join(' ') || 'No message'}\n\n`;
        for (let mem of participants) {
            text += `@${mem.id.split('@')[0]}\n`;
        }
        await sock.sendMessage(from, { text, mentions: participants.map(a => a.id) }, { quoted: msg });
    },
    tagadmins: async (sock, msg, from, args, isGroup) => {
        if (!isGroup) return sock.sendMessage(from, { text: "This command only works in groups." }, { quoted: msg });
        const groupMetadata = await sock.groupMetadata(from);
        const admins = groupMetadata.participants.filter(v => v.admin !== null).map(v => v.id);
        let text = `📢 *Tag Admins*\n\n${args.join(' ') || 'No message'}\n\n`;
        for (let admin of admins) {
            text += `@${admin.split('@')[0]}\n`;
        }
        await sock.sendMessage(from, { text, mentions: admins }, { quoted: msg });
    },
    glink: async (sock, msg, from, args, isGroup) => {
        if (!isGroup) return sock.sendMessage(from, { text: "This command only works in groups." }, { quoted: msg });
        const code = await sock.groupInviteCode(from);
        await sock.sendMessage(from, { text: `https://chat.whatsapp.com/${code}` }, { quoted: msg });
    }
};
