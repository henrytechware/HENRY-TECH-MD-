const db = require('../../lib/database');
const os = require('os');

module.exports = {
    restart: async (sock, msg, from, args) => {
        await sock.sendMessage(from, { text: "Restarting bot..." }, { quoted: msg });
        process.exit(0);
    },
    block: async (sock, msg, from, args) => {
        const user = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : msg.message.extendedTextMessage?.contextInfo?.participant;
        if (!user) return sock.sendMessage(from, { text: "Please mention a user or provide a number." }, { quoted: msg });
        await sock.updateBlockStatus(user, 'block');
        await sock.sendMessage(from, { text: `✅ User ${user} blocked.` }, { quoted: msg });
    },
    unblock: async (sock, msg, from, args) => {
        const user = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : msg.message.extendedTextMessage?.contextInfo?.participant;
        if (!user) return sock.sendMessage(from, { text: "Please mention a user or provide a number." }, { quoted: msg });
        await sock.updateBlockStatus(user, 'unblock');
        await sock.sendMessage(from, { text: `✅ User ${user} unblocked.` }, { quoted: msg });
    },
    autostatus: async (sock, msg, from, args) => {
        const settings = db.getSettings();
        db.updateSettings({ autoViewStatus: !settings.autoViewStatus });
        await sock.sendMessage(from, { text: `✅ Auto-view status: ${!settings.autoViewStatus ? 'ON' : 'OFF'}` }, { quoted: msg });
    },
    autorecording: async (sock, msg, from, args) => {
        const settings = db.getSettings();
        db.updateSettings({ autoRecording: !settings.autoRecording });
        await sock.sendMessage(from, { text: `✅ Auto-recording: ${!settings.autoRecording ? 'ON' : 'OFF'}` }, { quoted: msg });
    },
    autotyping: async (sock, msg, from, args) => {
        const settings = db.getSettings();
        db.updateSettings({ autoTyping: !settings.autoTyping });
        await sock.sendMessage(from, { text: `✅ Auto-typing: ${!settings.autoTyping ? 'ON' : 'OFF'}` }, { quoted: msg });
    },
    setprefix: async (sock, msg, from, args) => {
        if (!args[0]) return sock.sendMessage(from, { text: "Please provide a prefix." }, { quoted: msg });
        db.updateSettings({ prefix: args[0] });
        await sock.sendMessage(from, { text: `✅ Prefix set to: ${args[0]}` }, { quoted: msg });
    },
    private: async (sock, msg, from, args) => {
        db.updateSettings({ public: false });
        await sock.sendMessage(from, { text: "✅ Bot set to PRIVATE mode." }, { quoted: msg });
    },
    public: async (sock, msg, from, args) => {
        db.updateSettings({ public: true });
        await sock.sendMessage(from, { text: "✅ Bot set to PUBLIC mode." }, { quoted: msg });
    },
    ping: async (sock, msg, from, args) => {
        const start = Date.now();
        await sock.sendMessage(from, { text: "Pinging..." }, { quoted: msg });
        const end = Date.now();
        await sock.sendMessage(from, { text: `Latency: ${end - start}ms` }, { quoted: msg });
    },
    uptime: async (sock, msg, from, args) => {
        const uptime = process.uptime();
        const hours = Math.floor(uptime / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);
        await sock.sendMessage(from, { text: `Uptime: ${hours}h ${minutes}m ${seconds}s` }, { quoted: msg });
    }
};
