const axios = require('axios');
const yts = require('yt-search');

module.exports = {
    google: async (sock, msg, from, args) => {
        if (!args[0]) return sock.sendMessage(from, { text: "Please provide a search query." }, { quoted: msg });
        const query = args.join(' ');
        await sock.sendMessage(from, { text: `🔍 Searching Google for: ${query}\n\nhttps://www.google.com/search?q=${encodeURIComponent(query)}` }, { quoted: msg });
    },
    youtube: async (sock, msg, from, args) => {
        if (!args[0]) return sock.sendMessage(from, { text: "Please provide a search query." }, { quoted: msg });
        const query = args.join(' ');
        const res = await yts(query);
        const video = res.videos[0];
        if (!video) return sock.sendMessage(from, { text: "No results found." }, { quoted: msg });
        const text = `📺 *YouTube Search*\n\n*Title:* ${video.title}\n*Duration:* ${video.timestamp}\n*Views:* ${video.views}\n*Link:* ${video.url}`;
        await sock.sendMessage(from, { image: { url: video.thumbnail }, caption: text }, { quoted: msg });
    },
    github: async (sock, msg, from, args) => {
        if (!args[0]) return sock.sendMessage(from, { text: "Please provide a search query." }, { quoted: msg });
        const query = args.join(' ');
        const res = await axios.get(`https://api.github.com/search/repositories?q=${encodeURIComponent(query)}`);
        const repo = res.data.items[0];
        if (!repo) return sock.sendMessage(from, { text: "No results found." }, { quoted: msg });
        const text = `📁 *GitHub Search*\n\n*Name:* ${repo.full_name}\n*Stars:* ${repo.stargazers_count}\n*Forks:* ${repo.forks_count}\n*Link:* ${repo.html_url}`;
        await sock.sendMessage(from, { text }, { quoted: msg });
    },
    bing: async (sock, msg, from, args) => {
        if (!args[0]) return sock.sendMessage(from, { text: "Please provide a search query." }, { quoted: msg });
        const query = args.join(' ');
        await sock.sendMessage(from, { text: `🔍 Searching Bing for: ${query}\n\nhttps://www.bing.com/search?q=${encodeURIComponent(query)}` }, { quoted: msg });
    },
    dict: async (sock, msg, from, args) => {
        if (!args[0]) return sock.sendMessage(from, { text: "Please provide a word." }, { quoted: msg });
        const word = args[0];
        try {
            const res = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
            const data = res.data[0];
            const text = `📖 *Dictionary*\n\n*Word:* ${data.word}\n*Definition:* ${data.meanings[0].definitions[0].definition}`;
            await sock.sendMessage(from, { text }, { quoted: msg });
        } catch (err) {
            await sock.sendMessage(from, { text: "Word not found." }, { quoted: msg });
        }
    },
    weather: async (sock, msg, from, args) => {
        if (!args[0]) return sock.sendMessage(from, { text: "Please provide a city." }, { quoted: msg });
        const city = args.join(' ');
        // Using a free API for demo purposes
        await sock.sendMessage(from, { text: `🌤️ Weather for ${city}: (Coming soon in full version)` }, { quoted: msg });
    },
    gemini: async (sock, msg, from, args) => {
        if (!args[0]) return sock.sendMessage(from, { text: "Please provide a prompt." }, { quoted: msg });
        await sock.sendMessage(from, { text: "🤖 Gemini is thinking..." }, { quoted: msg });
        // Placeholder for AI integration
        await sock.sendMessage(from, { text: "AI integration requires an API key. Please set it up in config.js." }, { quoted: msg });
    },
    chatgpt: async (sock, msg, from, args) => {
        if (!args[0]) return sock.sendMessage(from, { text: "Please provide a prompt." }, { quoted: msg });
        await sock.sendMessage(from, { text: "🤖 ChatGPT is thinking..." }, { quoted: msg });
        // Placeholder for AI integration
        await sock.sendMessage(from, { text: "AI integration requires an API key. Please set it up in config.js." }, { quoted: msg });
    }
};
