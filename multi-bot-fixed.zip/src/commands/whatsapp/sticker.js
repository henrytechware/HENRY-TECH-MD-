const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs-extra');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');

module.exports = {
    tosticker: async (sock, msg, from, args) => {
        const type = Object.keys(msg.message)[0];
        if (type !== 'imageMessage' && type !== 'videoMessage') {
            return sock.sendMessage(from, { text: "Please send an image or video with the command." }, { quoted: msg });
        }
        const stream = await downloadContentFromMessage(msg.message[type], type === 'imageMessage' ? 'image' : 'video');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        const inputPath = path.join(__dirname, `../../temp_${Date.now()}.webp`);
        await fs.writeFile(inputPath, buffer);
        await sock.sendMessage(from, { sticker: { url: inputPath } }, { quoted: msg });
        await fs.remove(inputPath);
    },
    take: async (sock, msg, from, args) => {
        await sock.sendMessage(from, { text: "Sticker 'take' feature: (Coming soon in full version)" }, { quoted: msg });
    },
    tocircle: async (sock, msg, from, args) => {
        await sock.sendMessage(from, { text: "Sticker 'tocircle' feature: (Coming soon in full version)" }, { quoted: msg });
    },
    slap: async (sock, msg, from, args) => {
        await sock.sendMessage(from, { text: "👋 Slap!" }, { quoted: msg });
    },
    smile: async (sock, msg, from, args) => {
        await sock.sendMessage(from, { text: "😊 Smile!" }, { quoted: msg });
    },
    sad: async (sock, msg, from, args) => {
        await sock.sendMessage(from, { text: "😢 Sad!" }, { quoted: msg });
    }
};
