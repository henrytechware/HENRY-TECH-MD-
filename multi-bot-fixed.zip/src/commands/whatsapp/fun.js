const axios = require('axios');

module.exports = {
    joke: async (sock, msg, from, args) => {
        const res = await axios.get('https://official-joke-api.appspot.com/random_joke');
        const joke = `${res.data.setup}\n\n${res.data.punchline}`;
        await sock.sendMessage(from, { text: joke }, { quoted: msg });
    },
    meme: async (sock, msg, from, args) => {
        const res = await axios.get('https://meme-api.com/gimme');
        await sock.sendMessage(from, { image: { url: res.data.url }, caption: res.data.title }, { quoted: msg });
    },
    truth: async (sock, msg, from, args) => {
        const truths = ["What is your biggest fear?", "What is your most embarrassing moment?", "Who is your secret crush?"];
        const truth = truths[Math.floor(Math.random() * truths.length)];
        await sock.sendMessage(from, { text: `*Truth:* ${truth}` }, { quoted: msg });
    },
    dare: async (sock, msg, from, args) => {
        const dares = ["Do 10 pushups.", "Sing a song and send it as a voice note.", "Send a screenshot of your recent chats."];
        const dare = dares[Math.floor(Math.random() * dares.length)];
        await sock.sendMessage(from, { text: `*Dare:* ${dare}` }, { quoted: msg });
    },
    compliment: async (sock, msg, from, args) => {
        const res = await axios.get('https://complimentr.com/api');
        await sock.sendMessage(from, { text: `*Compliment:* ${res.data.compliment}` }, { quoted: msg });
    },
    quote: async (sock, msg, from, args) => {
        const res = await axios.get('https://api.quotable.io/random');
        const quote = `"${res.data.content}"\n\n- ${res.data.author}`;
        await sock.sendMessage(from, { text: quote }, { quoted: msg });
    },
    tictactoe: async (sock, msg, from, args) => {
        await sock.sendMessage(from, { text: "Tic-Tac-Toe game started! (Coming soon in full version)" }, { quoted: msg });
    },
    wcg: async (sock, msg, from, args) => {
        await sock.sendMessage(from, { text: "Word Guessing Game started! (Coming soon in full version)" }, { quoted: msg });
    }
};
